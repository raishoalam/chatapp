import React, {useState} from 'react'

import './index.css'

function MessageInput({sendMessage}) {
  const [message, setMessage] = useState('')

  const handleMessageChange = event => {
    setMessage(event.target.value)
  }

  const handleSubmit = event => {
    event.preventDefault()
    sendMessage(message)
    setMessage('')
  }

  return (
    <div className="msg-chat">
      <h1 className="chat-heading">Chat App</h1>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          className="chat-input"
          value={message}
          onChange={handleMessageChange}
          placeholder="Type your message..."
        />
        <button type="submit" className="btn">
          Send
        </button>
      </form>
    </div>
  )
}

export default MessageInput
