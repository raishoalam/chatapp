// App.js
import React, {useState, useEffect} from 'react'
import socketIOClient from 'socket.io-client'
import ChatWindow from './ChatWindow'
import MessageInput from './MessageInput'

const ENDPOINT = 'http://localhost:8000' // Your backend server URL

function App() {
  const [messages, setMessages] = useState([])
  const socket = socketIOClient(ENDPOINT)

  useEffect(() => {
    socket.on('message', message => {
      setMessages([...messages, message])
    })
  }, [messages, socket])

  const sendMessage = message => {
    socket.emit('sendMessage', message)
  }

  return (
    <div className="App">
      <ChatWindow messages={messages} />
      <MessageInput sendMessage={sendMessage} />
    </div>
  )
}

export default App
